# Login system: register + login with MongoDB

Frontend (HTML/CSS/JS) -> Express API -> MongoDB Atlas. Passwords are hashed with bcrypt; sessions use JWT.

```
login-system/
├── backend/    Express + Mongoose API (deploy to Render)
└── frontend/   Static pages (deploy to Vercel)
```

## Run locally

1. **Backend**
   ```bash
   cd backend
   cp .env.example .env      # then fill in MONGODB_URI and JWT_SECRET
   npm install
   npm start
   ```
   Open http://localhost:5000, you should see `{"message":"Login API is running."}`.

2. **Frontend**: serve the `frontend/` folder (VS Code Live Server, port 5500, matches `FRONTEND_URL` in `.env.example`) and open `index.html`.

   Or from the terminal: `cd frontend && npx serve -l 5500`

## Deploy

- **Render (backend)**: Root Directory `backend`, Build `npm install`, Start `node server.js`. Set env vars `MONGODB_URI`, `JWT_SECRET`, `FRONTEND_URL`.
- **Vercel (frontend)**: Root Directory `frontend`, no build command.
- Change `API_URL` in `frontend/config.js` to your Render URL, then set `FRONTEND_URL` on Render to your exact Vercel URL (no trailing slash).

## Endpoints

| Method | Path | Purpose |
| --- | --- | --- |
| POST | /api/register | Create user (name, email, password) |
| POST | /api/login | Returns JWT + user |
| GET | /api/profile | Protected, needs `Authorization: Bearer <token>` |

Never commit `.env`. Use a long random `JWT_SECRET`.
